// John 3:16-17
// BUG FIX: replaced the old colored-square nav with real material icons
// outlined variant for inactive tabs, filled for the active one
import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'feed_screen.dart';
import 'profile_screen.dart';

class ShellScreen extends StatefulWidget {
  final String name;
  final String role;

  const ShellScreen({super.key, required this.name, required this.role});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

// BUG FIX: replaced static const colors with theme getters so light/dark mode
// actually changes the UI instead of staying stuck in dark palette
class _ShellScreenState extends State<ShellScreen> {
  Color get _bg => Theme.of(context).scaffoldBackgroundColor;
  Color get _border => Theme.of(context).dividerColor;
  Color get _textMuted => Theme.of(context).colorScheme.onSurfaceVariant;
  Color get _activeColor => Theme.of(context).colorScheme.primary;

  // BUG FIX: added icon data for each nav item
  static const _navItems = [
    _NavItem(label: 'Home',    icon: Icons.home_rounded,        activeIcon: Icons.home_rounded),
    _NavItem(label: 'Feed',    icon: Icons.explore_outlined,    activeIcon: Icons.explore_rounded),
    _NavItem(label: 'Profile', icon: Icons.person_outline,      activeIcon: Icons.person_rounded),
  ];

  // tracks which tab is visible — 0 = Home, 1 = Feed, 2 = Profile
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      // IndexedStack keeps all screens mounted and in memory
      // only the child at currentIndex is visible — the others are hidden but alive
      // this means scroll position and state are preserved when switching tabs
      body: IndexedStack(
        index: _currentIndex,
        children: [
          HomeScreen(name: widget.name, role: widget.role),
          const FeedScreen(),
          ProfileScreen(name: widget.name, role: widget.role),
        ],
      ),
      bottomNavigationBar: _buildNavBar(),
    );
  }

  Widget _buildNavBar() {
    return Container(
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: _border, width: 0.5)),
      ),
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(_navItems.length,
            (i) => _buildNavItem(_navItems[i], index: i)),
      ),
    );
  }

  Widget _buildNavItem(_NavItem item, {required int index}) {
    final isActive = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isActive ? item.activeIcon : item.icon,
            size: 20,
            color: isActive ? _activeColor : _textMuted,
          ),
          const SizedBox(height: 3),
          Text(
            item.label,
            style: TextStyle(
              fontSize: 9,
              color: isActive ? _activeColor : _textMuted,
            ),
          ),
        ],
      ),
    );
  }
}

// BUG FIX: helper data class so icon definitions live in one place
class _NavItem {
  final String label;
  final IconData icon;
  final IconData activeIcon;

  const _NavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });
}