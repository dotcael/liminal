// BUG FIX: extracted theme definitions into a shared file so light/dark toggle
// can reuse the exact same dark palette the app already uses
import 'package:flutter/material.dart';

class AppTheme {
  // dark theme is the original liminal palette — untouched
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF1a1a2e),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4a4aaa),
          brightness: Brightness.dark,
        ),
      );

  // light theme uses the same seed color but light brightness + a lighter bg
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF0F0F8),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4a4aaa),
          brightness: Brightness.light,
        ),
      );
}
